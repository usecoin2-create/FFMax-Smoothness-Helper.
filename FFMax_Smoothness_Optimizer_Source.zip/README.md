# FFMAX Smoothness Helper (Android project)

This is a basic Android companion app for people running Free Fire MAX through BlueStacks 5 on a Windows laptop.

## What it does
- Provides a safe, editable optimization checklist.
- Explains realistic FPS limits.
- Lets you keep a local test note while tuning settings.

## What it does not do
- It does not modify Free Fire MAX or BlueStacks files.
- It does not change Windows CPU/GPU settings.
- It does not unlock or guarantee 120–144 FPS.
- It does not bypass anti-cheat or game restrictions.

## Build an APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync to complete. Use JDK 17 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When the build finishes, click **locate** in the notification.
6. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, and compile SDK 35. Android Studio may offer compatible SDK installation if it is missing.
