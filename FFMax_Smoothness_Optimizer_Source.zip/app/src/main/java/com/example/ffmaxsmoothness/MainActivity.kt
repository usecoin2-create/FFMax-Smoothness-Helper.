package com.example.ffmaxsmoothness

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val green = Color.rgb(33, 150, 83)
    private val dark = Color.rgb(24, 28, 35)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 26)
            setBackgroundColor(Color.rgb(245, 247, 250))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("FFMAX SMOOTHNESS HELPER", 24f, dark, true))
        root.addView(text("For BlueStacks 5 (64-bit) and Windows laptops", 15f, Color.DKGRAY, false))
        root.addView(spacer(16))

        val warning = text(
            "Important: this app is a checklist and guide. It cannot directly change Windows CPU/GPU settings or unlock 120–144 FPS. Actual FPS depends on the laptop, emulator, game limits, and display.",
            14f, Color.rgb(130, 65, 0), false
        )
        warning.setPadding(14, 14, 14, 14)
        warning.setBackgroundColor(Color.rgb(255, 239, 213))
        root.addView(warning)
        root.addView(spacer(18))

        root.addView(text("Recommended starting settings", 19f, dark, true))
        addCheck(root, "Use 1280 × 720 resolution to reduce graphics load.")
        addCheck(root, "Set BlueStacks performance mode to High performance if available.")
        addCheck(root, "On an 8 GB RAM laptop, try 4 GB memory allocation and close other apps.")
        addCheck(root, "Try 2–4 CPU cores depending on your laptop and BlueStacks options.")
        addCheck(root, "Enable high FPS only if BlueStacks and the game offer the option.")
        addCheck(root, "Use low in-game graphics first; test changes one at a time.")
        addCheck(root, "Plug in the laptop and select Windows Best performance power mode.")
        addCheck(root, "Keep vents clear; stop testing if the laptop becomes unusually hot.")
        root.addView(spacer(18))

        root.addView(text("FPS target guide", 19f, dark, true))
        root.addView(text(
            "120–144 FPS is a target, not a promise. A 60 Hz laptop display cannot show all frames as distinct refreshes. If the game is unstable, prefer a stable lower cap over a fluctuating high number.",
            14f, Color.DKGRAY, false
        ))
        root.addView(spacer(18))

        root.addView(text("Quick test log", 19f, dark, true))
        root.addView(text("After each change, play the same training area for 3–5 minutes and note average FPS, stutters, and temperature.", 14f, Color.DKGRAY, false))
        val notes = android.widget.EditText(this).apply {
            hint = "Example: 60 FPS cap, low graphics, fewer stutters..."
            minLines = 3
            gravity = Gravity.TOP
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(notes, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = 10
        })

        val copyButton = Button(this).apply {
            text = "Show safe test reminder"
            setOnClickListener {
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("Test safely")
                    .setMessage("Change one setting at a time. Record FPS and stutters before and after. Restore the previous setting if performance gets worse. This helper does not modify Free Fire MAX or bypass anti-cheat.")
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
        root.addView(copyButton)
        root.addView(spacer(12))
        root.addView(text("No game-file edits • No anti-cheat bypass • No guaranteed FPS unlock", 12f, Color.GRAY, false))
    }

    private fun addCheck(root: LinearLayout, label: String) {
        val item = android.widget.CheckBox(this).apply {
            text = label
            textSize = 15f
            setTextColor(dark)
            setPadding(0, 5, 0, 5)
        }
        root.addView(item)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 5, 0, 5)
        }

    private fun spacer(height: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, height)
    }
}
